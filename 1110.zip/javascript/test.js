document.write("독립된 파일로 자바스크립트 만들기");
document.write("<p>");
document.write("파일의 확장자는 js이다.");
document.write("<br>");
document.write("파일명은 test.js 이다.");